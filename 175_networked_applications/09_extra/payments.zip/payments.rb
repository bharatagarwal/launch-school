# accepts a payment to POST /payments/create
# given a form, with first name, last name, card number, expiry date, ccv

# if any values are missing, re-render the form
# submitted values should be shown, and missing values should be indicated.

# check credit card number details -- 16 char.
# if everything checks out, display thanks you message.

# there should be a page showing all payments:
# full name, time of payment, last four digits of card, expiry date.
# markup given for table to show these details.

# /list (GET)
# /payment/new (GET & POST)
# / (RESET)
# reset at root.

require 'sinatra'
require 'sinatra/reloader'
# require 'pry'

enable :sessions

def valid_card?(string)
  string.size == 16
end

def valid_entries?(user_data)
  valid_card?(user_data[:card_number]) && user_data.values.all? { |val| val.size > 0 }
end

def invalid_entries(user_data)
  user_data.select do |k, v|
    if k == :card_number
      if valid_card?(v)
        false
      else
        true
      end
    elsif v.empty?
      true
    else
      false
    end
  end.keys.map(&:to_s)
end

helpers do
  def format_card(string)
    "****-****-****-#{string[12..15]}"
  end
end

get "/" do
  session[:users] = []
  erb :payments
end

get "/payments" do
  erb :payments
end


get '/payments/new' do
  erb :new
end

post '/payments/new' do
  user_details = {
    first_name: params[:first_name],
    last_name: params[:last_name],
    card_number: params[:card_number],
    expiry: params[:expiry],
    ccv: params[:ccv]
  }

  if valid_entries?(user_details) == false
    session[:message] = "#{invalid_entries(user_details).join(' & ')} invalid."
    erb :new
  else
    session[:users] ||= []

    session[:users] << user_details
    session[:users].last[:time] = Time.now.to_s
    session[:message] = "Thank you for your payment!"
    # binding.pry
    redirect '/payments'
  end
end